The data shared in this repository may be used per the terms of reference found in Appendix B of the Pekeliling Pelaksanaan Data Terbuka Bil.1/2015, accessible here:

https://www.data.gov.my/p/pekeliling-data-terbuka
